function translatepiglatin(str){
  let vowels = ["a", "e", "i", "o", "u"];
  let firstvowelindex = -1;
  let newWord = "";

  for (let i = 0; i < str.length; i++) {
    if (vowels.include(str[i])){
      firstvowelindex = i;
      break;
    }
    
   }

  if (firstvowelindex == -1) { 
    newWord = str + "way";
  } else if (firstvowelindex == 0) {

    newWord = str + "ay";

  } else {
    let consonants = str.slice(0, firstvowelindex);

    newWord = slicedString + consonantCluster + "ay";
    
  }

     return newWord;

    }


console.log(translatepiglatin("apple");
console.log(translatepiglatin("pig way");
console.log(translatepiglatin("grade");



